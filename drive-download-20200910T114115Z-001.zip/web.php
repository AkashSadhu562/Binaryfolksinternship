<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layout');
});


Route::get('theory.blade.php','Users@theory');
Route::get('login.blade.php','Users@login');
Route::get('signup.blade.php','Users@signup');
Route::get('code.blade.php','Users@code');
//Route::get('login.blade.php','Users@loginsubmit');
Route::get('ca.blade.php','Users@ca');
Route::get('os.blade.php','Users@os');
Route::get('cn.blade.php','Users@cn');
Route::get('de.blade.php','Users@de');
Route::get('se.blade.php','Users@se');
Route::get('c.blade.php','Users@c');
Route::get('shell.blade.php','Users@shell');
Route::get('html.blade.php','Users@html');
Route::get('vhdl.blade.php','Users@vhdl');
Route::get('cc.blade.php','Users@cc');
Route::get('matlab.blade.php','Users@matlab');
Route::get('java.blade.php','Users@java');
Route::get('cplus.blade.php','Users@cplus');
Route::get('python.blade.php','Users@python');
Route::get('layout.blade.php','Users@layout');
Route::get('more.blade.php','Users@more');
