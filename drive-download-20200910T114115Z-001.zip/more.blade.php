<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <title></title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<style>
    html, body {
        background-color: #fff;
        color: #636b6f;
        font-family: 'Nunito', sans-serif;
        font-weight: 200;
        height: 100vh;
        margin: 0;
    }



    .flex-center {
        align-items: center;
        display: flex;
        justify-content: center;
    }

    .position-ref {
        position: relative;
    }

    .top-right {
        position: absolute;
        right: 10px;
        top: 18px;
    }

    .content {
        text-align: center;
    }
    .content{
        background-color: #32CD32;
    }


    .links > a {
        color: #ffffff;
        background-color: #636b6f;
        padding: 0 25px;
        font-size: 13px;
        font-weight: 600;
        letter-spacing: .1rem;
        text-decoration: none;
        text-transform: uppercase;
    }

    .m-b-md {
        margin-bottom: 30px;
    }
    .footer{
        text-align: center;
    }
    .footer{
        background-color: #32CD32;
    }
    .navbar{
        font-weight:bold;
        font-family:blue;
    }
</style>
<body style="background-color:#32CD32;">

<div class="content" style="font-family: blue">
    <div class="title m-b-md">
        More
    </div>


    <div class="links">
        <a href="https://www.gainyourcode.com/about/">About Us</a>
        <a href="https://www.gainyourcode.com/contact-us/">Contact Us</a>
        <a href="https://www.gainyourcode.com/privacy-policy/">Privacy Policy</a>
        <a href="https://www.gainyourcode.com/copyright/">Copyright And Disclaimer</a>
    </div>
</div>
<div class="footer" style="font-family: blue">
    <div class="title m-b-md">
        Follow Us On
    </div>
    <div class="links">
        <a href="https://www.youtube.com/channel/UCv7ar1ubohsj6W3aiqwjqgQ">Youtube</a>
        <a href="https://m.facebook.com/Gainyourcode-101216071512497/?ref=bookmarks">Facebook</a>
        <a href="https://www.instagram.com/gainyourcode/">Instagram</a>
    </div>
</div>
</body>
</html>
