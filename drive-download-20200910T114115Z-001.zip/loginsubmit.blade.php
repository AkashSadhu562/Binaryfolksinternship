<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <title></title>
</head>
<body>
<h1>LogIn Successful</h1>
</body>
</html>
