<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class users extends Controller
{
    //

    function theory()
    {
        return view('theory');
    }
    function login()
    {
        return view('login');
    }
    function signup()
    {
        return view('signup');
    }
    function code()
    {
        return view('code');
    }
    function ca()
    {
        return view('ca');
    }
    function os()
    {
        return view('os');
    }
    function de()
    {
        return view('de');
    }
    function se()
    {
        return view('se');
    }
    function cn()
    {
        return view('cn');
    }
    function cc()
    {
        return view('cc');
    }
    function shell()
    {
        return view('shell');
    }
    function vhdl()
    {
        return view('vhdl');
    }
    function c()
    {
        return view('c');
    }
    function html()
    {
        return view('html');
    }
    function python()
    {
        return view('python');
    }
    function matlab()
    {
        return view('matlab');
    }
    function cplus()
    {
        return view('cplus');
    }
    function layout()
    {
        return view('layout');
    }
    function more()
    {
        return view('more');
    }
    function loginsubmit(Request $req)
    {
        User::all();
        print_r($req->input());
    }

}
